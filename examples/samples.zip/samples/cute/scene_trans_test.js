//******************************************************
// Sprite 
// Show "Sprite" and add actions
//
//******************************************************
Import("cocos2d/*");
//set landscape
setOrientation(0);
var kTagParticleCount = 1;
//get director
var director = CCDirector.sharedDirector();

//create main scene and layer
var myScene = CCScene.create();
var demoIndex = 0;
var backGround = ["Images/background.png", "Images/background1.png", "Images/background2.png", "Images/background3.png"];

var Transitions = [
					[CCTransitionFlipAngular, cocos2d.kCCTransitionOrientationLeftOver],
					[CCTransitionPageTurn, false], 
					[CCTransitionZoomFlipX, cocos2d.kCCTransitionOrientationLeftOver], 
					[CCTransitionZoomFlipX, cocos2d.kCCTransitionOrientationRightOver],
					[CCTransitionZoomFlipY, cocos2d.kCCTransitionOrientationUpOver],
					[CCTransitionZoomFlipY, cocos2d.kCCTransitionOrientationDownOver],
					[CCTransitionPageTurn, true],
					[CCTransitionFade, cocos2d.ccc3(255, 255, 255)]];
					
function createMenuAndBg(container) {
	var size = director.getWinSize();
	var bg1 = CCSprite.create(backGround[demoIndex % 4]);
	bg1.setPosition( cocos2d.ccp(size.width/2, size.height/2) );
	container.addChild(bg1, 0);
	
	var s = director.getWinSize();
	var label = CCLabelTTF.create(container.title, "Arial", 28);
	container.addChild(label, 100, 1000);
	label.setPosition( cocos2d.ccp(s.width/2, s.height-50) );
	var nextScene = function() {
		var newScene = CCScene.create();			
		var layer = CCLayer.create();
		layer.onEnter = function() {			
				director.setDepthTest(false);
				createMenuAndBg(this);					
		};
		layer.title = "transition demo";
		layer.setController(layer);
		//addChild must be called after setController
		newScene.addChild(layer);
		var pScene = Transitions[demoIndex][0].create(1.2, newScene, Transitions[demoIndex][1]);			
		director.replaceScene(pScene);
	}
	var item1 = CCMenuItemImage.create("Images/b1.png", "Images/b2.png", container, function(){
		demoIndex--;
		if (demoIndex < 0) demoIndex = 5;
		nextScene();
	});
	var item2 = CCMenuItemImage.create("Images/r1.png", "Images/r2.png", container, function(){
		printf("item2 clicked");
	});
	var item3 = CCMenuItemImage.create("Images/f1.png", "Images/f2.png", container, function(){
		demoIndex++;
		if (demoIndex >= Transitions.length) demoIndex = 0;
		nextScene();
	});

	var menu = CCMenu.createWithArray([item1, item2, item3]);		   
	menu.setPosition( cocos2d.ccp(0, 0) );
	item1.setPosition(cocos2d.ccp(240 - item2.getContentSize().width*2, 0 + item2.getContentSize().height/2));
	item2.setPosition(cocos2d.ccp(240, 0 + item2.getContentSize().height/2));
	item3.setPosition(cocos2d.ccp(240 + item2.getContentSize().width*2, 0 + item2.getContentSize().height/2));
  
	container.addChild( menu, 100 );
}
function demo()
{
	var myLayer = CCLayerColor.create(cocos2d.ccc4(127,127,127,255));//CCLayer.create();
	
	myLayer.title = "transition demo";
	
	
	myLayer.onEnter = function() {
    	director.setDepthTest(false);
		createMenuAndBg(this);	
	};
	
	myLayer.setController(myLayer);
	//addChild must be called after setController
	myScene.addChild(myLayer);

}

demo();
director.pushScene(myScene);
garbageCollect();