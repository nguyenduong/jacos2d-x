Import("box2d/*");
Import("test_physic.js/Test");

var Tiles = SubClass("Tiles", Test, function() {
	var e_count = 20;
	var _super = this._super();
	m_fixtureCount = 0;
    var timer = new b2Timer();
	{
		var a = 0.5;
		var bd = new b2BodyDef();
		bd.position.y = -a;
		var ground = this.m_world.CreateBody(bd);

		var N = 200;
		var M = 10;
		var position = new b2Vec2(0, 0);
            
		for (var j = 0; j < M; ++j)
		{
			position.x = -N * a;

			for (var i = 0; i < N; ++i)
			{
				var shape = new b2PolygonShape();
				shape.SetAsBox(a, a, position, 0.0);
                ground.CreateFixture(shape, 0.0);
                ++m_fixtureCount;
                position.x += 2.0 * a;
            }
            position.y -= 2.0 * a;
		}
	}
	{
		var a = 0.5;
        var shape = new b2PolygonShape();
        shape.SetAsBox(a, a);

        var x = new b2Vec2(-7.0, 0.75);
        var y = new b2Vec2(0, 0);
        var deltaX = new b2Vec2(0.5625, 1.25);
        var deltaY = new b2Vec2(1.125, 0.0);

        for (var i = 0; i < e_count; ++i)
        {
			y.x = x.x;
			y.y = x.y;
			
			for (var j = i; j < e_count; ++j)
            {
				var bd = new b2BodyDef();
                bd.type = b2_dynamicBody;
                bd.position.Set(y.x, y.y);

                var body = this.m_world.CreateBody(bd);
                body.CreateFixture(shape, 5.0);
                ++m_fixtureCount;
                y.x += deltaY.x;
				y.y += deltaY.y;
            }

            x.x += deltaX.x;
			x.y += deltaX.y;
		}
    }

    m_createTime = timer.GetMilliseconds();
	this.Step = function(settings) {
        var cm = this.m_world.GetContactManager();
        var height = cm.m_broadPhase.GetTreeHeight();
        var leafCount = cm.m_broadPhase.GetProxyCount();
        var minimumNodeCount = 2 * leafCount - 1;
        var minimumHeight = Math.ceil(Math.log(minimumNodeCount) / Math.log(2.0));
        //this.m_debugDraw.DrawString(5, m_textLine, "dynamic tree height = %d, min = %d", height, int32(minimumHeight));
        //m_textLine += 15;
		
        //_super.Step(settings);
		this._call(this._super.Step, settings);

        //m_debugDraw.DrawString(5, m_textLine, "create time = %6.2f ms, fixture count = %d",m_createTime, m_fixtureCount);
        //m_textLine += 15;
	};
}, true);

Exports(Tiles);