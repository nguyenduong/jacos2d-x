//******************************************************
// Sprite 
// Show "Sprite" and add actions
//
//******************************************************
Import("cocos2d/CCDirector, CCScene, CCLayer");
Import("cocos2d/CCMenuItemImage, CCLabelTTF, CCMenu, CCNode");
Import("box2d/*");

//get director
var director = CCDirector.sharedDirector();
//create main scene and layer
var myScene = CCScene.create();

Import("Tumbler.js/Tumbler");

Import("tiles_physic.js/Tiles");
Import("gear_physic.js/Gear");
Import("cantilever_physic.js/Cantilever");
Import("TheoJansen_physic.js/TheoJansen");
setOrientation(0); 
var PTM_RATIO = 32;
var kTagParentNode = 1;
var kTagBox2DNode = 1235;

//var Tumbler = {};
var g_testEntries = [
	{name : "Tumbler", _class : Tumbler},
	{name : "Tiles", _class : Tiles},
	{name : "Gear", _class : Gear},
	{name : "Cantilever", _class : Cantilever},
	{name : "TheoJansen", _class : TheoJansen}
];

printf("tumb: " + Tumbler);
var settings = {
	viewCenter : new b2Vec2(0, 20),
	hz : 60,
	velocityIterations : 8,
	positionIterations : 3,
	drawShapes : 1,
	drawJoints : 1,
	drawAABBs : 0,
	drawPairs : 0,
	drawContactPoints : 0,
	drawFrictionForces : 0,
	drawCOMs : 0,
	drawStats : 0,
	drawProfile : 0,
	enableWarmStarting : 1,
	enableContinuous : 1,
	enableSubStepping : 0,
	pause : 0,
	singleStep : 0	
};

var node = CCNode.create();
var Box2DView = SubClass("Box2DView", CCLayer, function() {
	printf("Box2DView base");
	this._super();
	//printf("addChild: " + base);
	//printf("addChild: " + base.addChild);
	//this._call(base.addChild, node);
		
	
	//private members
	this.m_entry = null;
	var		m_test;
	var		m_entryID;
	
	//private methods
	var tick = function(dt) {
		//printf("tick: " + dt);
		this.m_test.Step(settings);
	};
	
	//public methods
	this.initWithEntryID = function(entryId) {
		printf("init 0");
		this.setTouchEnabled(true);
		printf("init 1");
		this.schedule(tick);
		printf("init 2");
		m_entry = g_testEntries[entryId];
		printf("init 3 + " + m_entry);
		this.m_test = new m_entry._class();
		printf("init 4");
		m_test = this.m_test;
		this.title = m_entry.name;
		//printf("MouseDown: " + this.m_test.MouseDown);
		
		director.getTouchDispatcher().addTargetedDelegate(this, 0, true);
		return true;
	};
	
	this.title = "Box2D view";
	
	//override draw function, must call this.setBaseEventListener(this);
	this.draw = function() {
		cocos2d.ccGLEnableVertexAttribs(cocos2d.kCCVertexAttribFlag_Position);
		kmGLPushMatrix();
		if (m_test)
			m_test.m_world.DrawDebugData();
		kmGLPopMatrix();
		
	};
	this.ccTouchBegan = function(touch) {
		var touchLocation = touch.getLocation();    
		printf("m_test" + m_test);
		//printf("MouseDown" + m_test.MouseDown);
		var nodePosition = this.convertToNodeSpace( touchLocation );
		return this.m_test.MouseDown(new b2Vec2(nodePosition.x,nodePosition.y));   
	};
	this.ccTouchMoved = function(touch) {
		var touchLocation = touch.getLocation();
		var nodePosition = this.convertToNodeSpace( touchLocation );
		this.m_test.MouseMove(new b2Vec2(nodePosition.x,nodePosition.y)); 
	};
	this.ccTouchEnded = function(touch) {
		var touchLocation = touch.getLocation();
		var nodePosition = this.convertToNodeSpace( touchLocation );    
		this.m_test.MouseUp(new b2Vec2(nodePosition.x,nodePosition.y));
	};		
	
	this.setController(this);
});
function ClsA() {};
ClsA.prototype = new CCLayer();
ClsA.prototype.test = function() {};

var kk = new ClsA();
//static method
Box2DView.viewWithEntryID = function(entryId) {
	var view = new Box2DView();
	printf("====== type of: " + (view instanceof CCLayer));
	view.initWithEntryID(entryId);
	return view;
};
_pp = null;
var MenuLayer = SubClass("MenuLayer", CCLayer, function(){
	this._super();
	
	
	//private members
	var m_entryID = 0;
	//private methods
	var restartCallback = function(sender) {
		myScene = CCScene.create();
		var box = MenuLayer.menuWithEntryID(m_entryID);
		director.replaceScene( myScene );
	};
	var nextCallback = function(sender) {
	
		myScene = CCScene.create();
		var next = m_entryID + 1;
		if( next >= g_testEntries.length)
			next = 0;
		var box = MenuLayer.menuWithEntryID(next);
		director.replaceScene( myScene );

	};
	var backCallback = function(sender) {
	
		myScene = CCScene.create();
		var prev = m_entryID - 1;
		if( prev < 0)
			prev = g_testEntries.length - 1;
		var box = MenuLayer.menuWithEntryID(prev);
		director.replaceScene( myScene );
	};
	printf("Hello");
	//public methods
	this.initWithEntryID = function(entryId) {		
		var visibleOrigin = director.getVisibleOrigin();
		var visibleSize = director.getVisibleSize();
		m_entryID = entryId;
    
		this.setTouchEnabled( true );
		
		director.getTouchDispatcher().addTargetedDelegate(this, 0, true);
		
		var view = Box2DView.viewWithEntryID( entryId );
		this.addChild(view, 0, kTagBox2DNode);
		
		_pp = view;
		view.setScale(15);
		view.setAnchorPoint( cocos2d.ccp(0,0) );
		view.setPosition( cocos2d.ccp(visibleOrigin.x+visibleSize.width/2, visibleOrigin.y+visibleSize.height/3) );
		
		//var label = CCLabelTTF.create(view.title, "Arial", 28);
		var label = CCLabelTTF.create("Hello", "Arial", 28);
		this.addChild(label, 1);
		label.setPosition( cocos2d.ccp(visibleOrigin.x+visibleSize.width/2, visibleOrigin.y+visibleSize.height-50) );

		var item1 = CCMenuItemImage.create("Images/b1.png", "Images/b2.png", this, backCallback);
		var item2 = CCMenuItemImage.create("Images/r1.png","Images/r2.png", this, restartCallback);
		var item3 = CCMenuItemImage.create("Images/f1.png", "Images/f2.png", this, nextCallback);

		var menu = CCMenu.createWithArray([item1, item2, item3]);

		menu.setPosition( cocos2d.ccp(0, 0) );
		item1.setPosition(cocos2d.ccp(visibleSize.width / 2 - item2.getContentSize().width*2, item2.getContentSize().height/2));
		item2.setPosition(cocos2d.ccp(visibleSize.width / 2, item2.getContentSize().height/2));
		item3.setPosition(cocos2d.ccp(visibleSize.width / 2 + item2.getContentSize().width*2, item2.getContentSize().height/2));
    
		this.addChild(menu, 1);    
		
    return true;
	};
	this.registerWithTouchDispatcher = function() {
	};
	this.ccTouchBegan = function(touch) {
		return true;
	};
	this.ccTouchMoved = function(touch) {		
		var diff = touch.getDelta();    
		var node = this.getChildByTag( kTagBox2DNode );
		var currentPos = node.getPosition();
		node.setPosition( cocos2d.ccpAdd(currentPos, diff) );
	};
		
	this.setController(this);
})
MenuLayer.menuWithEntryID = function(id) {
	var myLayer = new MenuLayer();
	myScene.addChild(myLayer);
	myLayer.initWithEntryID(id);
	return myLayer;
}
	/*
	var myLayer = new MenuLayer();
	printf("1");
	myScene.addChild(myLayer);
	printf("2");
	myLayer.initWithEntryID(3);
	*/
MenuLayer.menuWithEntryID(0);
/**/
/*
var myLayer = CCLayer.create();
myLayer.schedule(function(dt) {
	printf("test");
});*/
//_pp.schedule(function() {});
director.pushScene(myScene);
garbageCollect();