Import("box2d/*");
Import("test_physic.js/Test");
//var Test = LoadModule("test_physic.js").Test;
printf(">>>>TEST: " + Test);
var Tumbler = SubClass("Tumbler", Test, function() {
	var e_count = 800;
	 this._super();
	 
	 printf("m_world: " + this.m_world);
	 //printf("MouseDown: " + this.MouseDown);
	 var ground = null;
	 var m_joint = null;
	 
     {
		var bd = new b2BodyDef();
        ground = this.m_world.CreateBody(bd);
     }
     {
		var bd = new b2BodyDef();
        bd.type = b2_dynamicBody;
        bd.allowSleep = false;
        bd.position.Set(0.0, 10.0);
        var body = this.m_world.CreateBody(bd);

        var shape = new b2PolygonShape();
        shape.SetAsBox(0.5, 10.0, new b2Vec2( 10.0, 0.0), 0.0);
        body.CreateFixture(shape, 5.0);
        shape.SetAsBox(0.5, 10.0, new b2Vec2(-10.0, 0.0), 0.0);
        body.CreateFixture(shape, 5.0);
        shape.SetAsBox(10.0, 0.5, new b2Vec2(0.0, 10.0), 0.0);
        body.CreateFixture(shape, 5.0);
        shape.SetAsBox(10.0, 0.5, new b2Vec2(0.0, -10.0), 0.0);
        body.CreateFixture(shape, 5.0);

        var jd = new b2RevoluteJointDef();
        jd.bodyA = ground;
        jd.bodyB = body;
        jd.localAnchorA.Set(0.0, 10.0);
        jd.localAnchorB.Set(0.0, 0.0);
        jd.referenceAngle = 0.0;
        jd.motorSpeed = 0.05 * Math.PI;
        jd.maxMotorTorque = 1e8;
        jd.enableMotor = true;
        m_joint = this.m_world.CreateJoint(jd);
		printf("Tumbler ok!");
	}

    m_count = 0;

	this.Step = function(settings) {		
		this._call(this._super.Step, settings);
		if (m_count < e_count) {
			var bd = new b2BodyDef();
            bd.type = b2_dynamicBody;
            bd.position.Set(0.0, 10.0);
            var body = this.m_world.CreateBody(bd);

            var shape = new b2PolygonShape();
            shape.SetAsBox(0.125, 0.125);
            body.CreateFixture(shape, 1.0);

            ++m_count;
		}
	};
}, true);

Exports(Tumbler);