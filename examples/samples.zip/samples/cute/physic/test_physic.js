printf("=======box2d: " + box2d);
printf("=======box2d: " + box2d.b2ContactListener);

Import("box2d/*");
var k_maxContactPoints = 2048;

var Test = SubClass("Test", b2ContactListener, function() {	
	this._super();
	
	printf("test_physic base");
	var m_textLine;
	
	//public members	
	this.m_worldAABB = new b2AABB();
	this.mPoints = [];
	this.m_destructionListener = {};
	//DuongNT
	this.m_debugDraw = box2d.getDefaultDebugDraw();
	
	this.m_bomb = null;
	this.m_mouseJoint = null;
	this.m_bombSpawnPoint = new b2Vec2(0, 0);
	this.m_bombSpawning = false;
	this.m_mouseWorld = new b2Vec2(0, 0);
	this.m_stepCount = 0;
	this.m_maxProfile = null;
	this.m_totalProfile = null;

	//start constructor
	var gravity = new b2Vec2(0.0, -10);
	this.m_world = new b2World(gravity);
	this.m_pointCount = 0;
	this.m_textLine = 30;
	//this.m_destructionListener.test = this;
	//this.m_world.SetDestructionListener(this.m_destructionListener);
	//this.m_world.SetContactListener(this);
	this.m_world.SetDebugDraw(this.m_debugDraw);
	
	printf("test_physic m_world created");
	
	var bodyDef = new b2BodyDef();
	
	this.m_groundBody = this.m_world.CreateBody(bodyDef);
	
	//public methods
	this.SetTextLine = function(line) {
		this.m_textLine = line;
	};
	this.DrawTitle = function(x, y, string) {
		this.m_debugDraw.DrawString(x, y, string);
	};
	this.Step = function(settings) {
	
		var timeStep = settings.hz > 0.0 ? 1.0 / settings.hz : 0.0;
		//printf("step");
		var flags = 0;
		flags += settings.drawShapes            * b2Draw.e_shapeBit;
		flags += settings.drawJoints            * b2Draw.e_jointBit;
		flags += settings.drawAABBs            * b2Draw.e_aabbBit;
		flags += settings.drawPairs            * b2Draw.e_pairBit;
		flags += settings.drawCOMs                * b2Draw.e_centerOfMassBit;
		this.m_debugDraw.SetFlags(flags);
		
		this.m_world.SetWarmStarting(settings.enableWarmStarting > 0);
		this.m_world.SetContinuousPhysics(settings.enableContinuous > 0);
		this.m_world.SetSubStepping(settings.enableSubStepping > 0);

		//m_pointCount = 0;

		this.m_world.Step(timeStep, settings.velocityIterations, settings.positionIterations);

		this.m_world.DrawDebugData();
	};
	this.ShiftMouseDown = function(point) {
	};
	this.MouseDown = function(point) {
		this.m_mouseWorld = point;
		if (this.m_mouseJoint)
			return false;
		var aabb = new b2AABB();
		var d = new b2Vec2(0.001, 0.001);
		aabb.lowerBound = new b2Vec2(point.x - d.x, point.y - d.y);
		
		aabb.upperBound = new b2Vec2(point.x + d.x, point.y + d.y);

		// Query the world for overlapping shapes.
		//QueryCallback callback(p);
		var _fixture = null;
		this.m_world.QueryAABB(function(fixture) {
			var body = fixture.GetBody();
			if (body.GetType() == box2d.b2_dynamicBody)
			{
				var inside = fixture.TestPoint(point);
				if (inside)
				{
					_fixture = fixture;
					// We are done, terminate the query.
					return false;
				}
			}
			// Continue the query.
			return true;
		}, aabb);

		if (_fixture)
		{
			var body = _fixture.GetBody();
			var md = new b2MouseJointDef();
			md.bodyA = this.m_groundBody;
			md.bodyB = body;
			md.target = point;
			md.maxForce = 1000.0 * body.GetMass();
			var joint = this.m_world.CreateJoint(md);
			this.m_mouseJoint = b2MouseJoint.tryCastFromb2Joint(joint);
			printf(">> Mouse joint: " + this.m_mouseJoint);
			body.SetAwake(true);
			return true;
		}
		return false;
		
	};
	this.MouseUp = function(point) {
		if (this.m_mouseJoint)
		{
			this.m_world.DestroyJoint(this.m_mouseJoint);
			this.m_mouseJoint = null;
		}
	};
	this.MouseMove = function(point) {
		this.m_mouseWorld = point;
    
		if (this.m_mouseJoint)
		{
			//printf("mouse joint: " + this.m_mouseJoint);
			this.m_mouseJoint.SetTarget(point);
		}
	};
	this.LaunchBomb = function() {
	};
	this.SpawnBomb = function(worldPoint) {
	};
	this.CompleteBombSpawn = function(point) {
	};
	this.JointDestroyed = function(joint) {
	};
	this.BeginContact = function(contact) {
	};
	this.EndContact = function(contact) {
	};
	this.PreSolve = function(contact, oldManifold) {
	    var manifold = contact.GetManifold();
		if (manifold.pointCount == 0)
		{
			return;
		}

		var fixtureA = contact.GetFixtureA();
		var fixtureB = contact.GetFixtureB();

		var states = b2GetPointStates(oldManifold, manifold);
		var state1 = states.state1;
		var state2 = states.state2;
		
		var worldManifold = new b2WorldManifold();
		contact.GetWorldManifold(worldManifold);

		for (var i = 0; i < manifold.pointCount && m_pointCount < k_maxContactPoints; ++i)
		{
			var cp = this.m_points[this.m_pointCount];
			cp.fixtureA = fixtureA;
			cp.fixtureB = fixtureB;
			cp.position = worldManifold.getPointAt(i);
			cp.normal = worldManifold.normal;
			cp.state = state2[i];
			++m_pointCount;
		}
	};
	this.PostSolve = function(contact, impulse) {
	};
	
});

Exports(Test);