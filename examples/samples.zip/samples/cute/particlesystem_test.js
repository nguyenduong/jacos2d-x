//******************************************************
// Sprite 
// Show "Sprite" and add actions
//
//******************************************************
Import("cocos2d/*");

//set landscape
setOrientation(0);

var kTagParticleCount = 1;
//get director
var director = CCDirector.sharedDirector();

//create main scene and layer
var myScene = CCScene.create();
var demoIndex = 0;
printf("hey----");
function demoParticle(demo)
{
	printf("test----");
	var myLayer = CCLayerColor.create(cocos2d.ccc4(127,127,127,255));//CCLayer.create();
	printf("-----------");
	myLayer.title = "Sun demo";
	myLayer.subTitle = "sun";
	printf("start set onEnter func");
	myLayer.onEnter = function() {
		printf("onEnter");
		this.m_emitter = null;
    
		this.setTouchEnabled( true );
		this.setTouchMode(cocos2d.kCCTouchesOneByOne);
		
		var s = director.getWinSize();
		var label = CCLabelTTF.create(this.title, "Arial", 28);
		this.addChild(label, 100, 1000);
		label.setPosition( cocos2d.ccp(s.width/2, s.height-50) );
    
		var sub = CCLabelTTF.create(this.subTitle, "Arial", 16);
		this.addChild(sub, 100);
		sub.setPosition(cocos2d.ccp(s.width/2, s.height-80));
        
		var item1 = CCMenuItemImage.create("Images/b1.png", "Images/b2.png", this, function(){
			printf("item1 clicked");
			myScene.removeAllChildrenWithCleanup(true);
			demoIndex--;
			if (demoIndex < 0) demoIndex = 3;
			demoParticle(demoIndex);
		});
		var item2 = CCMenuItemImage.create("Images/r1.png", "Images/r2.png", this, function(){
			printf("item2 clicked");
		});
		var item3 = CCMenuItemImage.create("Images/f1.png", "Images/f2.png", this, function(){
			myScene.removeAllChildrenWithCleanup(true);
			demoIndex++;
			if (demoIndex > 3) demoIndex = 0;
			printf("item3 clicked: " + demoIndex);
			demoParticle(demoIndex);
		});
		
		var item4 = CCMenuItemToggle.createWithTarget(this, function() {
														if (this.m_emitter)
														{
															if( this.m_emitter.getPositionType() == cocos2d.kCCPositionTypeGrouped )
																this.m_emitter.setPositionType( cocos2d.kCCPositionTypeFree );
															else if (this.m_emitter.getPositionType() == cocos2d.kCCPositionTypeFree)
																this.m_emitter.setPositionType(cocos2d.kCCPositionTypeRelative);
															else if (this.m_emitter.getPositionType() == cocos2d.kCCPositionTypeRelative)
																this.m_emitter.setPositionType( cocos2d.kCCPositionTypeGrouped );
														}
													  },
                                                      [CCMenuItemFont.create( "Free Movement" ),
                                                       CCMenuItemFont.create( "Relative Movement" ),
                                                       CCMenuItemFont.create( "Grouped Movement" )
                                                      ]);
		
		var menu = CCMenu.createWithArray([item1, item2, item3, item4]);
		    
		menu.setPosition( cocos2d.ccp(0, 0) );
		item1.setPosition(cocos2d.ccp(240 - item2.getContentSize().width*2, 0 + item2.getContentSize().height/2));
		item2.setPosition(cocos2d.ccp(240, 0 + item2.getContentSize().height/2));
		item3.setPosition(cocos2d.ccp(240 + item2.getContentSize().width*2, 0 + item2.getContentSize().height/2));
		item4.setPosition( cocos2d.ccp( 0, 100) );
		item4.setAnchorPoint( cocos2d.ccp(0,0) );
    
		this.addChild( menu, 100 );
    
		var labelAtlas = CCLabelAtlas.create("0000", "fps_images.png", 12, 32, 46 /*'.'*/);
		this.addChild(labelAtlas, 100, kTagParticleCount);
		labelAtlas.setPosition(cocos2d.ccp(s.width-66,50));
    
		// moving background
		this.m_background = CCSprite.create("Images/background3.png");
		this.addChild(this.m_background, 5);
		this.m_background.setPosition( cocos2d.ccp(s.width/2, s.height-180) );
    
		var move = CCMoveBy.create(4, cocos2d.ccp(300,0) );
		var move_back = move.reverse();
		var seq = CCSequence.createWithTwoActions( move, move_back);
		this.m_background.runAction( CCRepeatForever.create(seq) );
		printf("init demo: " + demoIndex);
    		
		switch (demoIndex) {
			case 0: 
				this.m_emitter = CCParticleSun.create();
				this.m_background.addChild(this.m_emitter, 10);    
				this.m_emitter.setTexture( CCTextureCache.sharedTextureCache().addImage("Images/fire.png") );					
				break;
			case 1:
				this.m_emitter = CCParticleFire.create();
				
				this.m_background.addChild(this.m_emitter, 10);
				this.m_emitter.setTexture( CCTextureCache.sharedTextureCache().addImage("Images/fire.png") );//.pvr");
				//printf(this.m_emitter);
				//var p = this.m_emitter.getPosition();
				this.m_emitter.setPosition( cocos2d.ccp(0, 100) );
				break;
			case 2:
				this.m_emitter = CCParticleGalaxy.create();
				this.m_background.addChild(this.m_emitter, 10);    
				this.m_emitter.setTexture( CCTextureCache.sharedTextureCache().addImage("Images/fire.png") );
				break;
			case 3:
				this.m_emitter = CCParticleFlower.create();				
				this.m_background.addChild(this.m_emitter, 10);
				this.m_emitter.setTexture( CCTextureCache.sharedTextureCache().addImage("Images/stars.png") );
				break;
		}		
		var s = CCDirector.sharedDirector().getWinSize();
		if (this.m_emitter)
		{
			this.m_emitter.setPosition( cocos2d.ccp(s.width / 2, s.height / 2) );
		}
	};
	myLayer.setController(myLayer);
	//addChild must be called after setBaseEventListener
	myScene.addChild(myLayer);
	
	myLayer.ccTouchBegan = function(touch)
	{
		printf("touch begin");
		var location = touch.getLocation();		
		//return location.x > 32 && location.y > 32;
		return true;
	};
	myLayer.ccTouchEnded = function(touch)
	{
		printf("touch end");
		var location = touch.getLocation();

		var pos = cocos2d.ccp(0, 0);
	
		if (this.m_background)
		{
			pos = this.m_background.convertToWorldSpace(cocos2d.ccp(0, 0));
		}

		if (this.m_emitter)
		{
			this.m_emitter.setPosition( cocos2d.ccpSub(location, pos) );    
		}
	};
	printf("finished");
}

demoParticle(0);
director.pushScene(myScene);
garbageCollect();