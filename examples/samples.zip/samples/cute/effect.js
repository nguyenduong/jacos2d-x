//******************************************************
// Sprite 
// Show "Sprite" and add actions
//
//******************************************************
Import("cocos2d/CCDirector, CCScene,CCLayer, CCLabelTTF, CCSprite, CCRotateBy, CCMoveTo, CCSequence, CCPoint, CCSpawn, CCCallFunc");
Import("cocos2d/CCWaves, CCPageTurn3D, CCShaky3D, CCTwirl, CCLabelBMFont, CCLayerColor, CCWaves3D, CCNode, CCMoveBy, CCRepeatForever, CCScaleBy");
//get director
var director = CCDirector.sharedDirector();

//create main scene and layer
var myScene = CCScene.create();
var myLayer = CCLayerColor.create(cocos2d.ccc4(32,128,32,255));
	myScene.addChild(myLayer);
	
	var node = CCNode.create();
	var effect = CCWaves3D.create(5, 40, cocos2d.ccg(15,10), 3);
	//var effect =  CCWaves.create(4, 20, true, true, cocos2d.ccg(16,12), 3);
	
	//size = director.getWinSize();
    //var effect = CCTwirl.create(cocos2d.ccp(size.width/2, size.height/2), 1, 2.5, cocos2d.ccg(12,8), 3);
	//page turn 3D
	//director.setDepthTest(true);
    //var effect = CCPageTurn3D.create(cocos2d.ccg(15,10), 3); 
	
	/*Sharky*/
	//var effect = CCShaky3D.create(5, false, cocos2d.ccg(15,10), 3);
	
	node.runAction(CCRepeatForever.create(effect));
	//node.runAction(effect);
	myLayer.addChild(node, 0);
	
	var bg = CCSprite.create("Images/background3.png");
    node.addChild(bg, 0);
    bg.setPosition(cocos2d.ccp(240, 160));
	
	var grossini = CCSprite.create("Images/grossinis_sister2.png");
    node.addChild(grossini, 1);
    grossini.setPosition( cocos2d.ccp(480 / 3, 160) );
    var sc = CCScaleBy.create(2, 5);
    var sc_back = sc.reverse();
    grossini.runAction( CCRepeatForever.create(CCSequence.createWithTwoActions(sc, sc_back)) );
	
	var tamara = CCSprite.create("Images/grossinis_sister1.png");
    node.addChild(tamara, 1);
    tamara.setPosition( cocos2d.ccp(2* 480/3, 160) );
    var sc2 = CCScaleBy.create(2, 5);
    var sc2_back = sc2.reverse();
    tamara.runAction( CCRepeatForever.create(CCSequence.createWithTwoActions(sc2, sc2_back)));
	
	/*
	CCNode* node = CCNode::create();
    CCActionInterval* effect = getAction();
    node->runAction(effect);
    addChild(node, 0, kTagBackground);
    
    CCSprite *bg = CCSprite::create(s_back3);
    node->addChild(bg, 0);
//  bg->setAnchorPoint( CCPointZero );
    bg->setPosition(VisibleRect::center());

    CCSprite* grossini = CCSprite::create(s_pPathSister2);
    node->addChild(grossini, 1);
    grossini->setPosition( ccp(VisibleRect::left().x+VisibleRect::getVisibleRect().size.width/3,VisibleRect::center().y) );
    CCActionInterval* sc = CCScaleBy::create(2, 5);
    CCActionInterval* sc_back = sc->reverse();
    grossini->runAction( CCRepeatForever::create((CCActionInterval*)(CCSequence::create(sc, sc_back, NULL)) ) );

    CCSprite* tamara = CCSprite::create(s_pPathSister1);
    node->addChild(tamara, 1);
    tamara->setPosition( ccp(VisibleRect::left().x+2*VisibleRect::getVisibleRect().size.width/3,VisibleRect::center().y) );
    CCActionInterval* sc2 = CCScaleBy::create(2, 5);
    CCActionInterval* sc2_back = sc2->reverse();
    tamara->runAction( CCRepeatForever::create((CCActionInterval*)(CCSequence::create(sc2, sc2_back, NULL))) );
    
    CCLabelTTF* label = CCLabelTTF::create((effectsList[actionIdx]).c_str(), "Marker Felt", 32);
    
    label->setPosition( ccp(VisibleRect::center().x,VisibleRect::top().y-80) );
    addChild(label);
    label->setTag( kTagLabel );

    CCMenuItemImage *item1 = CCMenuItemImage::create(s_pPathB1, s_pPathB2, this, menu_selector(TextLayer::backCallback) );
    CCMenuItemImage *item2 = CCMenuItemImage::create(s_pPathR1, s_pPathR2, this, menu_selector(TextLayer::restartCallback) );
    CCMenuItemImage *item3 = CCMenuItemImage::create(s_pPathF1, s_pPathF2, this, menu_selector(TextLayer::nextCallback) );

    CCMenu *menu = CCMenu::create(item1, item2, item3, NULL);

    menu->setPosition(CCPointZero);
    item1->setPosition(ccp(VisibleRect::center().x - item2->getContentSize().width*2, VisibleRect::bottom().y+item2->getContentSize().height/2));
    item2->setPosition(ccp(VisibleRect::center().x, VisibleRect::bottom().y+item2->getContentSize().height/2));
    item3->setPosition(ccp(VisibleRect::center().x + item2->getContentSize().width*2, VisibleRect::bottom().y+item2->getContentSize().height/2));
    
    addChild(menu, 1);    

    schedule( schedule_selector(TextLayer::checkAnim) );*/

	director.pushScene(myScene);
//garbageCollect();