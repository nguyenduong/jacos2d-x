//******************************************************
// Sprite 
// Show "Sprite" and add actions
//
//******************************************************
Import("cocos2d/CCDirector, CCScene, CCLayer");
Import("cocos2d/CCLayerColor, CCSprite, CCJumpTo, CCFadeIn, CCMoveTo, CCRotateTo");
Import("cocos2d/CCRepeatForever, CCSequence, CCFadeOut");
var kTagSprite = 1;
//get director
var director = CCDirector.sharedDirector();

//create main scene and layer
var myScene = CCScene.create();
var myLayer = CCLayer.create();
myScene.addChild(myLayer);


myLayer.setTouchEnabled(true);

var sprite = CCSprite.create("Images/grossini.png");

var layer = CCLayerColor.create(cocos2d.ccc4(255,255,0,255));
myLayer.addChild(layer, 0);

myLayer.addChild(sprite, 1, kTagSprite);
sprite.setPosition( cocos2d.ccp(20,150) );

sprite.runAction( CCJumpTo.create(4, cocos2d.ccp(300,48), 100, 4) );
layer.runAction( CCRepeatForever.create(CCSequence.createWithTwoActions(CCFadeIn.create(1), CCFadeOut.create(1)))); 

var listener = {
	ccTouchesEnded : function(touches) {
		printf("touch");
		var touch = touches[0];
		var location = touch.getLocation();
	
		sprite.stopAllActions();	
		sprite.runAction( CCMoveTo.create(1, cocos2d.ccp(location.x, location.y) ) );
	
		var o = location.x - sprite.getPositionX();
		var a = location.y - sprite.getPositionY();
		var at =  Math.atan( o/a) * 180 / Math.PI;    
		if( a < 0 ) 
		{
			if(  o < 0 )
				at = 180 + Math.abs(at);
			else
				at = 180 - Math.abs(at);    
		}
    
		sprite.runAction( CCRotateTo.create(1, at) );
	}
}
myLayer.setController(listener);

director.pushScene(myScene);
//garbageCollect();