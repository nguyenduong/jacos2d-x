//******************************************************
// Sprite 
// Show "Sprite" and add actions
//
//******************************************************
Import("cocos2d/*");
//get director
var director = CCDirector.sharedDirector();
//set landscape
setOrientation(0);
//create main scene and layer
var myScene = CCScene.create();
var myLayer = CCLayer.create();

var label1 = CCLabelAtlas.create("123 Test", "fonts/tuffy_bold_italic-charmap.plist");

myLayer.addChild(label1);
label1.setPosition(new CCPoint(10,100));
label1.setOpacity( 200 );

var label2 = CCLabelAtlas.create("0123456789", "fonts/tuffy_bold_italic-charmap.plist");
myLayer.addChild(label2);
label2.setPosition( new CCPoint(10,200) );
label2.setOpacity( 32 );
	
var label3 = CCLabelBMFont.create("Test", "fonts/bitmapFontTest2.fnt", -1, 0);
// testing anchors
label3.setAnchorPoint( cocos2d.ccp(0.5, 0.5) );
label3.setPosition( new CCPoint(100,250) );
label3.setColor(cocos2d.ccc3(255, 10, 128));
myLayer.addChild(label3);	
	
myScene.addChild(myLayer);
myLayer.setTouchEnabled( true );
myLayer.ccTouchesEnded = function(touches) {
		var point = touches[0];
		printf("Touch end: " + cocos2d.kCCLabelAutomaticWidth);
		
	};
	
director.pushScene(myScene);
garbageCollect();