//******************************************************
// Sprite 
// Show "Sprite" and add actions
//
//******************************************************

Import("cocos2d/*");
Import("box2d/*");
var PTM_RATIO = 32;
var kTagParentNode = 1;
//get director
var director = CCDirector.sharedDirector();

//create main scene and layer
var myScene = CCScene.create();

var myLayer = CCLayer.create();
//create label
var guideLabel = CCLabelTTF.create("Touch here!!", "Arial", 20);
windowSize = director.getWinSize();
guideLabel.setPosition(windowSize.width / 2, windowSize.height / 2);
myLayer.addChild(guideLabel);

var world;
var UndefinedClass = function() {
	this.assign = function(Cls) {
		this.prototype = Cls.prototype;
		for (var key in Cls) {
			this[key] = Cls[key];
		}
	};
}
function Test() {
	var x = 100;
	this.setX = function(newX) {
		x = newX;
	};
	this.f1 = function(k) {
		printf("----------: " + (k + x));
	};
}

var o_test = new Test();
o_test.f1(10);
o_test.setX(200);
o_test.f1(10);

var xx = function(newCls){
	xx = newCls;
}

var kkk = CCLayer;
xx(CCLayer);
//ResolvePendingClass(xx, CCLayer);
//ResolvePendingClass(xx, kkk);
//xx.assign(CCLayer);
printf("=======" + JSON.stringify(xx));
printf("=======" + JSON.stringify(CCLayer));
printf("-------XX: " + xx);
function initPhysic() {

	var gravity = new b2Vec2(0.0, -10);
    world = new b2World(gravity);
	world.SetAllowSleeping(true);
	world.SetContinuousPhysics(true);
	var flags = b2Draw.e_shapeBit;
	var groundBodyDef = new b2BodyDef();
	groundBodyDef.position.Set(0, 0);
	groundBody = world.CreateBody(groundBodyDef);
	
	groundBox = new b2EdgeShape();
	
    // bottom
    groundBox.Set(new b2Vec2(0, 0), new b2Vec2(windowSize.width/PTM_RATIO, 0));
    groundBody.CreateFixture(groundBox,0);

    // top
    groundBox.Set(new b2Vec2(0, windowSize.height / PTM_RATIO), new b2Vec2(windowSize.width / PTM_RATIO, windowSize.height/PTM_RATIO));
    groundBody.CreateFixture(groundBox,0);

    // left
    groundBox.Set(new b2Vec2(0, windowSize.height/PTM_RATIO), new b2Vec2(0, 0));
    groundBody.CreateFixture(groundBox, 0);

    // right
    groundBox.Set(new b2Vec2(windowSize.width / PTM_RATIO, 0), new b2Vec2(windowSize.width / PTM_RATIO, windowSize.height / PTM_RATIO));
    groundBody.CreateFixture(groundBox, 0);
}

var parent = CCSpriteBatchNode.create("Images/blocks.png", 100);
parent.setTag(18);
var m_pSpriteTexture = parent.getTexture();

function addNewSpriteAtPosition(pos) {
	var parent = myLayer.getChildByTag(kTagParentNode);
	var idx = (Math.random() > 0.5 ? 0:1);
    var idy = (Math.random() > 0.5 ? 0:1);
			
    
    // Define the dynamic body.
    //Set up a 1m squared box in the physics world
    var bodyDef = new b2BodyDef();
    bodyDef.type = box2d.b2_dynamicBody;
    //bodyDef.position.Set(pos.x/PTM_RATIO, pos.y/PTM_RATIO);
	bodyDef.setPosition(pos.x/PTM_RATIO, pos.y/PTM_RATIO);
	
    var body = world.CreateBody(bodyDef);
    
    // Define another box shape for our dynamic body.
    var dynamicBox = new b2PolygonShape();
    dynamicBox.SetAsBox(0.5, 0.5);//These are mid points for our 1m box
    
    // Define the dynamic body fixture.
    var fixtureDef = new b2FixtureDef();
    fixtureDef.shape = dynamicBox;    
    fixtureDef.density = 1.0;
    fixtureDef.friction = 0.3;
    body.CreateFixture(fixtureDef);

	var sprite = new CCPhysicSprite(body);	
	sprite.initWithTexture(m_pSpriteTexture, cocos2d.CCRectMake(32 * idx,32 * idy,32,32));    	
	sprite.setPTMRatio(PTM_RATIO);
    parent.addChild(sprite);    
    sprite.setPosition( cocos2d.ccp( pos.x, pos.y) );
    
	
}

myLayer.setTouchEnabled(true);
myLayer.setAccelerometerEnabled(true);
initPhysic();
myLayer.addChild(parent, 0, kTagParentNode);

myLayer.setController({
	ccTouchesEnded : function(touches) {
		//Add a new body/atlas sprite at the touched location
		for (var i in touches) {
			var touch = touches[i];
			if (!touch) break;
			var location = touch.getLocation();
			printf("x: " + location.x + ", y: " + location.y);
			addNewSpriteAtPosition(location);
		}
	},
	update : function(dt) {
		var velocityIterations = 8;
		var positionIterations = 1;
	
		// Instruct the world to perform a single step of simulation. It is
		// generally best to keep the time step and iterations fixed.
		world.Step(dt, velocityIterations, positionIterations);
	}
});
myLayer.scheduleUpdate();
myScene.addChild(myLayer);
director.pushScene(myScene);
garbageCollect();