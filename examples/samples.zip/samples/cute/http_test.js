Import("cocos2d/CCFileUtils");
Import("jacos2dx/*");

var writeablePath = CCFileUtils.sharedFileUtils().getWriteablePath();
printf("Path: " + writeablePath);

var fs = new FileStream(writeablePath + "myfile.txt", FileStream.MODE_CREATE);
var os = fs.openOutputStream();

os.writeUTF8Line("Helloworld", jacos2dx._CR_LF);
os.flush();
fs.close();
//os.writeUTF8Line("cannot write this line!", jacos2dx._CR_LF);

var fr = new FileStream(writeablePath + "myfile.txt", FileStream.MODE_OPEN_READ);
var is = fr.openInputStream();
var s = is.readUTF8Line(jacos2dx._CR_LF);
printf("data: " + s);
fr.close();

var inf = GetJacosInfor();
printf("version: " + inf.version);
printf("author: " + inf.author);
printf("release_date: " + inf.release_date);
printf("release_at: " + inf.release_at);

/*Test HTTP connection
Import("cocos2d.extension/CCHttpRequest, CCHttpClient, CCHttpResponse");
var request = new CCHttpRequest();
request.setRequestType(CCHttpRequest.kHttpGet);
request.setUrl("http://dantri.com");
request.setResponseCallback(this, function(sender, response) {
	printf("Hello");
	var stream = response.getInputStream();
	var data = "";
	while (stream.available() > 0) 
	{
		//data += stream.readUTF8Line(jacos2dx._CR_LF);
		printf(stream.readUTF8Line(jacos2dx._CR_LF));
	}
	printf("data: " + data);
});

var httpClient = CCHttpClient.getInstance();
httpClient.send(request);
*/