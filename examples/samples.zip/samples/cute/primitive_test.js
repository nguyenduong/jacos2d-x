//******************************************************
// Sprite 
// Show "Sprite" and add actions
//
//******************************************************
Import("cocos2d/CCDirector, CCScene,CCLayer");
Import("cocos2d/CCGLProgram, CCNode, CCPointsList");

setOrientation(0);
//get director
var director = CCDirector.sharedDirector();

//create main scene and layer
var myScene = CCScene.create();
var myLayer = CCLayer.create();
myScene.addChild(myLayer);

myLayer.setController({
	//this function will be called from Node's draw function
	draw : function() { 
		//printf("on draw");
		
		cocos2d.ccLineWidth(1);
		cocos2d.ccDrawColor4B(255, 255,0,255);
		cocos2d.ccDrawLine( cocos2d.ccp(0, 0), cocos2d.ccp(480, 320) );

		cocos2d.ccLineWidth(3);
		cocos2d.ccDrawColor4B(255,0,0,255);
		cocos2d.ccDrawLine( cocos2d.ccp(0, 320), cocos2d.ccp(480, 0) );
		
		
		cocos2d.ccPointSize(64);
		cocos2d.ccDrawColor4B(0,0,255,128);
		cocos2d.ccDrawPoint( cocos2d.ccp(240, 160) );
		
		//draw bezier
		cocos2d.ccDrawQuadBezier(cocos2d.ccp(0, 320), cocos2d.ccp(240, 160), cocos2d.ccp(480, 320), 50);
		
		
		// draw cubic bezier path
		cocos2d.ccDrawColor4B(255,0,255,128);
		cocos2d.ccLineWidth(2.5);
		cocos2d.ccDrawCubicBezier(cocos2d.ccp(240, 160), cocos2d.ccp(240 + 30, 160 + 50), cocos2d.ccp(240 + 60, 160 - 50), cocos2d.ccp(480, 160),100);

		//draw polygon1
		if (!this.polygon1)
			this.polygon1 = new CCPointsList([cocos2d.ccp(60,160), cocos2d.ccp(70,190), cocos2d.ccp(100,190), cocos2d.ccp(90,160)]);		
		cocos2d.ccDrawSolidPoly(this.polygon1, cocos2d.ccc4f(1,1,0,1) );
		
		// filled poly
		cocos2d.ccLineWidth(1);
		if (!this.polygon2)
			this.polygon2 = new CCPointsList([ cocos2d.ccp(0,120), cocos2d.ccp(50,120), cocos2d.ccp(50,170), cocos2d.ccp(25,200), cocos2d.ccp(0,170)]);
		cocos2d.ccDrawSolidPoly(this.polygon2, cocos2d.ccc4f(0.5, 0.5, 1, 1 ) );
		
		// draw a green circle with 50 segments with line to center
		cocos2d.ccLineWidth(2);
		cocos2d.ccDrawColor4B(0, 255, 255, 255);
		cocos2d.ccDrawCircle( cocos2d.ccp(240, 160), 50, 90 / 180 * Math.PI, 50, true);
	    
		// open yellow poly
		cocos2d.ccDrawColor4B(255, 255, 0, 255);
		cocos2d.ccLineWidth(10);
		
		if (!this.polygon3)
			this.polygon3 = new CCPointsList([cocos2d.ccp(0,0), cocos2d.ccp(50,50), cocos2d.ccp(100,50), cocos2d.ccp(100,100), cocos2d.ccp(50,100)]);
		cocos2d.ccDrawPoly(this.polygon3, false);
		
		// draw a green circle with 10 segments
		cocos2d.ccLineWidth(16);
		cocos2d.ccDrawColor4B(0, 255, 0, 255);
		cocos2d.ccDrawCircle( cocos2d.ccp(240, 160), 100, 0, 10, false);
	}
});

director.pushScene(myScene);
//garbageCollect();