//******************************************************
// Sprite 
// Show "Sprite" and add actions
//
//******************************************************
Import("cocos2d/*");
//get director
var director = CCDirector.sharedDirector();
//set landscape
setOrientation(0);
//create main scene and layer
var myScene = CCScene.create();
var myLayer = CCLayer.create();
	myScene.addChild(myLayer);

    // Top Layer, a simple image
    var cocosImage = CCSprite.create("Images/powered.png");
    // scale the image (optional)
    cocosImage.setScale( 2.5 );
    // change the transform anchor point to 0,0 (optional)
    cocosImage.setAnchorPoint( cocos2d.ccp(0,0) );
    

    // Middle layer: a Tile map atlas
    var tilemap = CCTileMapAtlas.create("TileMaps/tiles.png", "TileMaps/levelmap.tga", 16, 16);
    tilemap.releaseMap();
    
    // change the transform anchor to 0,0 (optional)
    tilemap.setAnchorPoint( cocos2d.ccp(0, 0) );

    // Anti Aliased images
    tilemap.getTexture().setAntiAliasTexParameters();
    

    // background layer: another image
    var background = CCSprite.create("Images/background.png");
    // scale the image (optional)
    background.setScale( 1.5 );
    // change the transform anchor point (optional)
    background.setAnchorPoint( cocos2d.ccp(0,0) );

    
    // create a void node, a parent node
    var voidNode = CCParallaxNode.create();
    
    // NOW add the 3 layers to the 'void' node

    // background image is moved at a ratio of 0.4x, 0.5y
    voidNode.addChild(background, 0, cocos2d.ccp(0.4, 0.5), cocos2d.ccp(0,0));
    
    // tiles are moved at a ratio of 2.2x, 1.0y
    voidNode.addChild(tilemap, 1, cocos2d.ccp(2.2,1.0), cocos2d.ccp(0,-200) );
    
    // top image is moved at a ratio of 3.0x, 2.5y
    voidNode.addChild(cocosImage, 2, cocos2d.ccp(3.0,2.5), cocos2d.ccp(200,800) );
    
    
    // now create some actions that will move the 'void' node
    // and the children of the 'void' node will move at different
    // speed, thus, simulation the 3D environment
    var goUp = CCMoveBy.create(4, cocos2d.ccp(0,-500) );
    var goDown = goUp.reverse();
    var go = CCMoveBy.create(8, cocos2d.ccp(-1000,0) );
    var goBack = go.reverse();
    var seq = CCSequence.create([goUp, go, goDown, goBack]);
    voidNode.runAction( (CCRepeatForever.create(seq) ));
    
    myLayer.addChild( voidNode );
	director.pushScene(myScene);
//garbageCollect();