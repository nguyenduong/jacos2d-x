//******************************************************
// Sprite 
// Show "Sprite" and add actions
//
//******************************************************
Import("cocos2d/CCDirector, CCScene,CCLayer, CCLabelTTF, CCSprite, CCRotateBy, CCMoveTo, CCSequence, CCPoint, CCSpawn, CCCallFunc");
Import("cocos2d/CCLabelAtlas, CCLabelBMFont");
Import("cocos2d.extension/CCNodeLoaderLibrary, CCBReader, CCLayerLoader");
setOrientation(0); 
//get director
var director = CCDirector.sharedDirector();

//create main scene and layer
var myScene = CCScene.create();
var myLayer = CCLayer.create();

	/*
    var ccNodeLoaderLibrary = CCNodeLoaderLibrary.newDefaultCCNodeLoaderLibrary();
    
    //ccNodeLoaderLibrary->registerCCNodeLoader("HelloCocosBuilderLayer", HelloCocosBuilderLayerLoader::loader());

    // Create an autorelease CCBReader. 
    var ccbReader = new CCBReader(ccNodeLoaderLibrary);
    
    // Read a ccbi file.
    var node = ccbReader.readNodeGraphFromFile("ccb/HelloCocosBuilder.ccbi");*/
    
function openTest(fileName) {
	var ccNodeLoaderLibrary = CCNodeLoaderLibrary.newDefaultCCNodeLoaderLibrary();
    var loader = CCLayerLoader.loader();
    ccNodeLoaderLibrary.registerCCNodeLoader("TestHeaderLayer", loader);
	ccNodeLoaderLibrary.registerCCNodeLoader("HelloCocosBuilderLayer", loader);
	ccNodeLoaderLibrary.registerCCNodeLoader("TestMenusLayer", loader);
	ccNodeLoaderLibrary.registerCCNodeLoader("TestSpritesLayer", loader);
	ccNodeLoaderLibrary.registerCCNodeLoader("TestButtonsLayer", loader);
	ccNodeLoaderLibrary.registerCCNodeLoader("TestAnimationsLayer", loader);
	ccNodeLoaderLibrary.registerCCNodeLoader("TestParticleSystemsLayer", loader);
	ccNodeLoaderLibrary.registerCCNodeLoader("TestScrollViewsLayer", loader);
	loader.actions = {
		onBackClicked : function() {
			printf("back clicked!");
			director.popScene();
		}
	};

    /* Create an autorelease CCBReader. */
    var ccbReader = new CCBReader(ccNodeLoaderLibrary);
    
    /* Read a ccbi file. */
    var ret = ccbReader.readNodeGraphFromFile(fileName);
	ret.mAnimationManager = ccbReader.getAnimationManager();
	return ret;
}
	var node = openTest("ccb/HelloCocosBuilder.ccbi");
    if(node) {
        myScene.addChild(node);
		node.onMenuTestClicked = function(sender, eventID) {
			printf("on menu test clicked - sender: " + sender + " - eventID: " + eventID);
			var mnnode = openTest("ccb/ccb/TestMenus.ccbi");
			var myScene = CCScene.create();
			myScene.addChild(mnnode);
			director.pushScene(myScene);
			
			mnnode.mAnimationManager.getRootNode().onBackClicked = function() {
				printf("back clicked!");
				director.popScene();
			}
			mnnode.onMenuItemAClicked = function() {
				printf("Menu item A clicked");
				mnnode.mMenuItemStatusLabelBMFont.setString("Menu Item A clicked.");
			}
			
			mnnode.onMenuItemBClicked = function() {
				printf("Menu item B clicked");
				mnnode.mMenuItemStatusLabelBMFont.setString("Menu Item B clicked.");
			}
		};
		node.onSpriteTestClicked = function(sender, eventID) {
			printf("onSpriteTestClicked - sender: " + sender + " - eventID: " + eventID);
			var node = openTest("ccb/ccb/TestSprites.ccbi");
			var myScene = CCScene.create();
			myScene.addChild(node);
			director.pushScene(myScene);
		};
		node.onButtonTestClicked = function(sender, eventID) {
			printf("onButtonTestClicked - sender: " + sender + " - eventID: " + eventID);
			var node = openTest("ccb/ccb/TestButtons.ccbi");
			var myScene = CCScene.create();
			myScene.addChild(node);
			director.pushScene(myScene);
			node.onCCControlButtonClicked = function(sender, event) {
				printf("touch: eventID: " + event);
				node.mCCControlEventLabel.setString("touch: eventID: " + event);
			}
		};
		node.onAnimationsTestClicked = function(sender, eventID) {
			printf("onAnimationsTestClicked - sender: " + sender + " - eventID: " + eventID);
			var node = openTest("ccb/ccb/TestAnimations.ccbi");
			var myScene = CCScene.create();
			myScene.addChild(node);
			director.pushScene(myScene);
			
			node.onCCControlButtonIdleClicked = function() {
				printf(node.mAnimationManager);
				node.mAnimationManager.runAnimations("Idle", 0.3);
				
			};
			node.onCCControlButtonWaveClicked = function() {
				node.mAnimationManager.runAnimations("Wave", 0.3);
			};
			node.onCCControlButtonJumpClicked = function() {
				node.mAnimationManager.runAnimations("Jump", 0.3);
			};
			node.onCCControlButtonFunkyClicked = function() {
				node.mAnimationManager.runAnimations("Funky", 0.3);
			};
			
		};
		node.onParticleSystemTestClicked = function(sender, eventID) {
			printf("onParticleSystemTestClicked - sender: " + sender + " - eventID: " + eventID);
			var node = openTest("ccb/ccb/TestParticleSystems.ccbi");
			var myScene = CCScene.create();
			myScene.addChild(node);
			director.pushScene(myScene);
		};
		node.onScrollViewTestClicked = function(sender, eventID) {
			printf("onScrollViewTestClicked - sender: " + sender + " - eventID: " + eventID);
			var node = openTest("ccb/ccb/TestScrollViews.ccbi");
			var myScene = CCScene.create();
			myScene.addChild(node);
			director.pushScene(myScene);
		};
		node.mAnimationManager.getRootNode().onBackClicked = function() {
			printf("back clicked!2");
			director.popScene();
		}
	
    }

	
director.pushScene(myScene);
garbageCollect();