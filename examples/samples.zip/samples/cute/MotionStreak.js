//******************************************************
// Sprite 
// Show "Sprite" and add actions
//
//******************************************************
Import("cocos2d/*");

//set landscape
setOrientation(0);

//get director
var director = CCDirector.sharedDirector();

//create main scene and layer
var myScene = CCScene.create();
var myLayer = CCLayer.create();
myScene.addChild(myLayer);
function motionStreakTest1()
{
	var s = director.getWinSize();
	// the root object just rotates around
    var m_root = CCSprite.create("Images/r1.png");
    myLayer.addChild(m_root, 1);
    m_root.setPosition(cocos2d.ccp(s.width/2, s.height/2));
  
    // the target object is offset from root, and the streak is moved to follow it
    var m_target = CCSprite.create("Images/r1.png");
    m_root.addChild(m_target);
    m_target.setPosition(cocos2d.ccp(s.width/4, 0));

    // create the streak object and add it to the scene
    var streak = CCMotionStreak.create(2, 3, 32, cocos2d.ccc3(0, 255, 0), "Images/streak.png");
    myLayer.addChild(streak);
    // schedule an update on each frame so we can syncronize the streak with the target

	director.getScheduler().scheduleSelector(this, function(){
		 streak.setPosition( m_target.convertToWorldSpace(cocos2d.ccp(0, 0)) );
	}, 0, false);
	
    var a1 = CCRotateBy.create(2, 360);

    var action1 = CCRepeatForever.create(a1);
    var motion = CCMoveBy.create(2, cocos2d.ccp(100,0) );
    m_root.runAction( CCRepeatForever.create(CCSequence.createWithTwoActions(motion, motion.reverse())));
    m_root.runAction( action1 );

	
    var colorAction = CCRepeatForever.create(CCSequence.create(
	   [CCTintTo.create(0.2, 255, 0, 0),
        CCTintTo.create(0.2, 0, 255, 0),
        CCTintTo.create(0.2, 0, 0, 255),
        CCTintTo.create(0.2, 0, 255, 255),
        CCTintTo.create(0.2, 255, 255, 0),
        CCTintTo.create(0.2, 255, 0, 255),
        CCTintTo.create(0.2, 255, 255, 255)
		]).tryCastToCCActionInterval());	
    streak.runAction(colorAction);
}

function Issue1358Test()
{
	// ask director the the window size
    var size = director.getWinSize();
    
    streak = CCMotionStreak.create(2.0, 1.0, 50.0, cocos2d.ccc3(255, 255, 0), "Images/Icon.png");
    myLayer.addChild(streak);
    
    
    m_center  = cocos2d.ccp(size.width/2, size.height/2);
    m_fRadius = size.width/3;
    m_fAngle = 0.0;
    	
	director.getScheduler().scheduleSelector(this, function(){
		m_fAngle += 1.0;

		streak.setPosition(cocos2d.ccp(m_center.x + Math.cos(m_fAngle/180 * Math.PI)*m_fRadius,
                            m_center.y + Math.sin(m_fAngle/ 180 *  Math.PI)*m_fRadius));
	}, 0, false);	
    
}

//motionStreakTest1();

Issue1358Test();

director.pushScene(myScene);
//garbageCollect();