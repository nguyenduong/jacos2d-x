//******************************************************
// Sprite 
// Show "Sprite With action" and add actions
//
//******************************************************


Import("cocos2d/*");

//get director
var director = cocos2d.CCDirector.sharedDirector();

//create main scene and layer
var helloWorldScene = CCScene.create();
var helloWorldLayer = CCLayer.create();

windowSize = director.getWinSize();
//create sprite
var sprite = CCSprite.create("jacos2dx.png");
sprite.setScale(0.5);
//rotate 360 degree in 5 seconds
var rotationAction = CCRotateBy.create(3.0, 360 * 5);
var moveAction = CCMoveTo.create(3, new CCPoint(0, 0));

var seq = CCSequence.createWithTwoActions(rotationAction, moveAction);
var moveRot = CCSpawn.createWithTwoActions(CCMoveTo.create(3, new CCPoint(windowSize.width / 2, windowSize.height)), rotationAction);
seq = CCSequence.createWithTwoActions(seq, moveRot);
seq = CCSequence.createWithTwoActions(seq, CCMoveTo.create(5, new CCPoint(windowSize.width / 2, windowSize.height / 2)));

sprite.runAction(CCRepeatForever.create(seq));
//sprite.runAction(seq);

sprite.setPosition(windowSize.width / 2, windowSize.height / 2);
helloWorldLayer.addChild(sprite);
helloWorldScene.addChild(helloWorldLayer);

director.pushScene(helloWorldScene);
