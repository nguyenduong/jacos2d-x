Import("cocos2d/CCScene, CCLayer, CCLabelTTF, CCDirector");

//get director
var director = CCDirector.sharedDirector();

//create main scene and layer
var helloWorldScene = CCScene.create();
var helloWorldLayer = CCLayer.create();

//create label
var lbHelloWorld = CCLabelTTF.create("Hello World!", "Arial", 20);
windowSize = director.getWinSize();
lbHelloWorld.setPosition(windowSize.width / 2, windowSize.height / 2);
helloWorldLayer.addChild(lbHelloWorld);
helloWorldScene.addChild(helloWorldLayer);

director.pushScene(helloWorldScene);
