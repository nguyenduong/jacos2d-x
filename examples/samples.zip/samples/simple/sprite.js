//******************************************************
// Sprite 
// Show "Sprite" and add actions
//
//******************************************************
Import("cocos2d/CCDirector, CCScene, CCLayer, CCLabelTTF");
Import("cocos2d/CCSprite");

//get director
var director = cocos2d.CCDirector.sharedDirector();

//create main scene and layer
var helloWorldScene = CCScene.create();
var helloWorldLayer = CCLayer.create();


//create sprite
var sprite = CCSprite.create("jacos2dx.png");
windowSize = director.getWinSize();
sprite.setPosition(windowSize.width / 2, windowSize.height / 2);
sprite.setRotation(30);

helloWorldLayer.addChild(sprite);

helloWorldScene.addChild(helloWorldLayer);

director.pushScene(helloWorldScene);
