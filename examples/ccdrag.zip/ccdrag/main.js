//******************************************************
// Sprite 
// Show "Sprite" and add actions
//
//******************************************************
Import("cocos2d/CCDirector, CCScene,CCLayer, CCLabelTTF, CCSprite, CCRotateBy, CCMoveTo, CCSequence, CCPoint, CCSpawn, CCCallFunc");
Import("cocos2d/CCLabelAtlas, CCLabelBMFont");
Import("cocos2d.extension/CCNodeLoaderLibrary, CCBReader, CCLayerLoader");

//set portrait
setOrientation(1); 
//get director
var director = CCDirector.sharedDirector();

//create main scene and layer
var myScene = CCScene.create();
var myLayer = CCLayer.create();
/*
var ccNodeLoaderLibrary = CCNodeLoaderLibrary.newDefaultCCNodeLoaderLibrary();
var loader = CCLayerLoader.loader();
ccNodeLoaderLibrary.registerCCNodeLoader("TestHeaderLayer", loader);
ccNodeLoaderLibrary.registerCCNodeLoader("HelloCocosBuilder", loader);
ccNodeLoaderLibrary.registerCCNodeLoader("TestMenuLayer", loader);
*/

var MainLayer = SubClass("MainLayer", CCLayer, function() {
	
});
MainLayer.prototype.openTest = function(fileName) {	
	printf("FileName: " + fileName);

	var ccbReader = new CCBReader(CCNodeLoaderLibrary.sharedCCNodeLoaderLibrary());
	var scene = ccbReader.createSceneWithNodeGraphFromFile(fileName);	
	director.pushScene(scene);
}

var layer = new MainLayer();
printf("test test");

layer.openTest("MainMenuScene.ccbi");

garbageCollect();