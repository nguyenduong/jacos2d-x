/* http://www.cocosbuilder.com
 * http://www.cocos2d-iphone.org
 *
 * Copyright (c) 2012 Zynga, Inc.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */

//
// controller for the Dragon Object (the Hero)
//

// Constants
var CD_START_SPEED = 8;
var CD_COIN_SPEED = 8;
var CD_START_TARGET = 160;

var CD_TARGET_FILTER_FACTOR = 0.05;
var CD_SLOW_DOWN_FACTOR = 0.995;
var CD_GRAVITY_SPEED = 0.1;
var CD_GAMEOVER_SPEED = -10;
var CD_DELTA_TO_ROTATION_FACTOR = 5;
var gScaleFactor = 1;
var Dragon = SubClass("Dragon", Object, function () {
	this._super();
    this.xTarget = CD_START_TARGET * gScaleFactor;
    this.ySpeed = CD_START_SPEED;
    this.radius = 25;
	this.controllerName = "Dragon";
	this._mhnt = 0;
	this.my_param = 0.1324543;
});
var count = 0;
Dragon.prototype.onUpdate = function () {
	
	/*
	count++;
	if (count >= 150) {
		garbageCollect();
		count = 0;
	}*/
    // Calculate the new position
    //var oldPosition = cocos2d.ccpMult(this.rootNode.getPosition(), 1.0 / gScaleFactor);
	var oldPosition = this.rootNode.getPosition();
	/*
	this.xTarget = 1;
	CD_TARGET_FILTER_FACTOR = 1;
	oldPosition.x = 1;
	*/
	
	//this.xTarget = CD_START_TARGET * gScaleFactor;
	//CD_TARGET_FILTER_FACTOR = 0.05;
	//oldPosition.x = 0.54;
	//printf("start update");
	var xt = this.controllerName;
	//printf("x target: " + xt);
	var ttt = this.my_param;
	//printf(">>my param: ");
	
	//printf(ttt);
	//printf(this.my_param);
    //var xNew = (this.xTarget / gScaleFactor) * CD_TARGET_FILTER_FACTOR + oldPosition.x * (1 - CD_TARGET_FILTER_FACTOR);
	var xNew = (this.xTarget / gScaleFactor) * CD_TARGET_FILTER_FACTOR + oldPosition.x * (1 - CD_TARGET_FILTER_FACTOR);
    
	var a = oldPosition.y;
	//printf("speed xNew: 0a - " + xNew);
	//printf("speed: 0 - " + a);
	
	var b = this.ySpeed;
	//printf("prepare speed 1- kk ");
	var kk = "" + this.ySpeed;
	//printf("prepare speed 1- ");
	//printf("speed: 1 - " + b);
	var yNew = a + b;
	//var val = (yNew * gScaleFactor);
	var val = 1;
    //printf("speed: 2: " + val);
	this.rootNode.setPosition(xNew * gScaleFactor, yNew * gScaleFactor);
	//printf("speed: 3");
	
    // Update the vertical speed
    //var cc = (b - CD_GRAVITY_SPEED) + CD_SLOW_DOWN_FACTOR;
	var cc = (b - CD_GRAVITY_SPEED) * CD_SLOW_DOWN_FACTOR;
	//printf("speed - 3b - " + cc);
	this.ySpeed = (b - CD_GRAVITY_SPEED) * CD_SLOW_DOWN_FACTOR;
	var kkk = 54;
	this.my_param = kkk + 5.4;
	//printf("MY PARAM");
	//printf(this.my_param);
	//this.my_param = ~~this.my_param;
	//b = (this.ySpeed - CD_GRAVITY_SPEED) * CD_SLOW_DOWN_FACTOR;
	//this.ySpeed = b;
	//printf("speed: 4 - " + this.ySpeed);
	//this.ySpeed = ~~this.ySpeed;
	//this.ySpeed = b;
	//printf("speed: 5");
    // Tilt the dragon
    var xDelta = xNew - oldPosition.x;
    this.rootNode.setRotation(xDelta * CD_DELTA_TO_ROTATION_FACTOR);	

    // Check for game over
	/*
    if (this.ySpeed < CD_GAMEOVER_SPEED) {
        //sharedGameScene.handleGameOver();
    }*/
	
};

Dragon.prototype.handleCollisionWith = function (gameObjectController) {
	
    if (gameObjectController.controllerName == "Coin") {
        // Took a coin
        this.ySpeed = CD_COIN_SPEED;
        //sharedGameScene.setScore(sharedGameScene.score + 1);
    }
    else if (gameObjectController.controllerName == "Bomb") {
        // Hit a bomb
        if (this.ySpeed > 0) this.ySpeed = 0;

        //this.rootNode.animationManager.runAnimationsForSequenceNamed("Hit");
    }
	
};
Exports(Dragon);